from my_project.math import add
from my_project.math import sub
from my_project.math import multiply
from my_project.math import divide