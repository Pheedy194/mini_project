from my_project.math import add
from my_project.math import sub
from my_project.math import multiply
from my_project.math import divide
def main():
    print("Welcome to mini calculator")
    print("choose operation:") = 
    print("1.add\n 2.sub\n 3.multiply\n 4.divide")

    choice = input("Enter choice(1/2/3/4):")
    a = float(input("Enter first number:"))
    b = float(input("Enter second number:"))

    if choice == '1':
        print("Result:",add(a,b))

    elif choice == '2':
        print("Result:",sub(a,b))

    elif choice == '3':
        print("Result:",multiply(a,b))

    elif choice == '4':
        print("Result:",divide(a,b))

    else:
        print("invalid choice")

    if __name__ == "__main__":
        main()

    
    