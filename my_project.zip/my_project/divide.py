def divide(a,b):
    if a!=0:
        return a/b

    else:
        print "error division by zero"