def sub(a,b):
    return a-b